shell.run("server")

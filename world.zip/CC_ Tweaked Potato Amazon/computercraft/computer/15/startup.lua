shell.run("potatoCounter", "14")

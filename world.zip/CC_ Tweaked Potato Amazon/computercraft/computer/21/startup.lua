shell.run("pipe", "u d")

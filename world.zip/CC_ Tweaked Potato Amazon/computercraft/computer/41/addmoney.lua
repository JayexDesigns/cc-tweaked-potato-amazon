rednet.open("right")
rednet.send(14, "jayex 15", "substractBalance")
local id, m, p = rednet.receive()
print(m)

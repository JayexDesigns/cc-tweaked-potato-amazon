rednet.open("right")
rednet.send(14, "testing aadmin", "registerRequest")
local id, m, p = rednet.receive()
print(m)

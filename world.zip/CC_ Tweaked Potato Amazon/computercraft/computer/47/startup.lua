shell.run("gps", "host", 24, 91, 28)

shell.run("gps", "host", 27, 94, 25)

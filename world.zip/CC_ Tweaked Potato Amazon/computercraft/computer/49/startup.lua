shell.run("gps", "host", 21, 94, 25)

print("hello world from disk")
